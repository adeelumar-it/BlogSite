import React from 'react';
import Card from '@mui/material/Card';
import CardActions from '@mui/material/CardActions';
import CardContent from '@mui/material/CardContent';
import CardMedia from '@mui/material/CardMedia';
function BlogArticle() {

    // Function to truncate text to a certain number of words
    const truncateText = (text, numWords) => {
        const words = text.split(' ');
        return words.slice(0, numWords).join(' ') + (words.length > numWords ? '...' : '');
    };


    const loremIpsumText =   "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum";

    return (
        <div className="flex flex-col md:flex-row p-6 bg-gray-100">
            {/* Left Column for Blog Article 1 */}
            <div className="md:max-w-4xl md:w-4/5 p-6 bg-white shadow-md md:mr-6 md:mb-0 mb-4">


                <Card className="p-2">


                    <img
                        src="https://mui.com/static/images/cards/contemplative-reptile.jpg"
                        alt="Image for Blog Article 1"
                        className="w-full md:w-1/2 mb-4 rounded-md"
                        style={{ height: 'auto' }}
                    />

                    <CardContent>
                        <h1 className="text-2xl font-bold mb-4">Blog Title 1</h1>
                        <p className="text-gray-700" id='blogdiscription'>
                        Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum


.
                        </p>
                       
                     
                    </CardContent>
                </Card>

            </div>

            {/* Right Column for Blog Article 2 */}
            <div className="md:max-w-lg md:w-1/5 p-6 bg-white shadow-md md:mb-0 hidden md:block">


                <Card className="p-2">
                    <img
                        src="https://cdn.pixabay.com/photo/2023/05/18/19/53/crocodile-8003173_1280.jpg"
                        alt="Image for Blog Article 2"
                        className="mb-4 rounded-md"
                    />
                    <CardContent>
                        <h1 className="text-2xl font-bold mb-4">Blog Title 2</h1>

                        <p className="text-gray-700" id='blogdiscription'>
                        Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum
                            
                            
                        </p>
                    </CardContent>
                </Card>



            </div>
        </div>

    );
}

export default BlogArticle;
