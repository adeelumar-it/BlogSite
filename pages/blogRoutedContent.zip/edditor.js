import * as React from 'react';
import { styled } from '@mui/material/styles';
import Box from '@mui/material/Box';
import Paper from '@mui/material/Paper';
import Grid from '@mui/material/Grid';

import Card from '@mui/material/Card';
import CardActions from '@mui/material/CardActions';
import CardContent from '@mui/material/CardContent';
import CardMedia from '@mui/material/CardMedia';

// import { TextareaAutosize } from '@mui/base';
// import TextField from '@mui/material/TextField';
// import Box from '@mui/material/Box';
import TextField from '@mui/material/TextField';
import Button from '@mui/material/Button';
import Stack from '@mui/material/Stack';
////
import DraftsOutlinedIcon from '@mui/icons-material/DraftsOutlined';
import SendIcon from '@mui/icons-material/Send';
import FormatBoldIcon from '@mui/icons-material/FormatBold';
import FormatItalicIcon from '@mui/icons-material/FormatItalic';
import FormatUnderlinedIcon from '@mui/icons-material/FormatUnderlined';
import FormatColorFillIcon from '@mui/icons-material/FormatColorFill';
import ArrowDropDownIcon from '@mui/icons-material/ArrowDropDown';
import ToggleButton from '@mui/material/ToggleButton';
import ToggleButtonGroup from '@mui/material/ToggleButtonGroup';
import CloseRoundedIcon from '@mui/icons-material/CloseRounded';

import FormatAlignLeftIcon from '@mui/icons-material/FormatAlignLeft';
import FormatAlignCenterIcon from '@mui/icons-material/FormatAlignCenter';
import FormatAlignRightIcon from '@mui/icons-material/FormatAlignRight';
// import FormatAlignJustifyIcon from '@mui/icons-material/FormatAlignJustify';
// import ToggleButton from '@mui/material/ToggleButton';
// import ToggleButtonGroup from '@mui/material/ToggleButtonGroup';
///LIST ITEMS
import ListSubheader from '@mui/material/ListSubheader';
import List from '@mui/material/List';
import ListItemButton from '@mui/material/ListItemButton';
import ListItemIcon from '@mui/material/ListItemIcon';
import ListItemText from '@mui/material/ListItemText';
import Collapse from '@mui/material/Collapse';
import InboxIcon from '@mui/icons-material/MoveToInbox';
import DraftsIcon from '@mui/icons-material/Drafts';
// import SendIcon from '@mui/icons-material/Send';
import ExpandLess from '@mui/icons-material/ExpandLess';
import ExpandMore from '@mui/icons-material/ExpandMore';
import StarBorder from '@mui/icons-material/StarBorder';
////radio group items

import Radio from '@mui/material/Radio';
import RadioGroup from '@mui/material/RadioGroup';
import FormControlLabel from '@mui/material/FormControlLabel';
import FormControl from '@mui/material/FormControl';
import FormHelperText from '@mui/material/FormHelperText';
import Link from 'next/link';

// ... (other imports)

export default function CustomizedDividers() {
  // ... (existing state and functions)



  const [alignment, setAlignment] = React.useState('left');
  const [formats, setFormats] = React.useState(() => ['bold', 'italic']);
  const [open, setOpen] = React.useState(false);
  const [value, setValue] = React.useState('');
  const [error, setError] = React.useState(false);
  const [helperText, setHelperText] = React.useState('Choose wisely');

  //// main things
  const [base64Image, setBase64Image] = React.useState('');
  const [content, setContent] = React.useState('');
    const [blogtitle, setblogtitle] = React.useState('');
  const [description, setdescription] = React.useState('');

  const [formData, setFormData] = React.useState({
    title: '',
    base64: '',
    description: '',
  });



  const handleChange = (e) => {
    setblogtitle( e.target.value)
    const { title, value } = e.target;

    
    setFormData((prevFormData) => ({
      ...prevFormData,
      [title]: value,
    }));
  };
  const handleContentChange = (event) => {
    setdescription(event.target.innerHTML);

  };


  const handleRadioChange = (event) => {
    setValue(event.target.value);
    setHelperText(' ');
    setError(false);
  };

  const handleSubmit = (event) => {
    event.preventDefault();

    if (value === 'best') {
      setHelperText('You got it!');
      setError(false);
    } else if (value === 'CustomDate') {


      setHelperText('select from Calender');
      setError(true);


    } else {
      setHelperText('Please select an option.');
      setError(true);
    }
  };
  const handleClick = () => {
    setOpen(!open);
  };
  const handleAlignment = (event, newAlignment) => {
    setAlignment(newAlignment);
  };


  const handleFormat = (event, newFormats) => {
    setFormats(newFormats);
  };
  const Item = styled(Paper)(({ theme }) => ({
    backgroundColor: theme.palette.mode === 'dark' ? '#1A2027' : '#fff',
    ...theme.typography.body2,
    padding: theme.spacing(1),
    textAlign: 'center',
    color: theme.palette.text.secondary,
  }));



  function handleImageInsertion(event) {
    const file = event.target.files[0];
    const reader = new FileReader();

    reader.onload = function (e) {
      const imgSrc = e.target.result;
      const img = new Image();
      img.src = imgSrc;
      img.alt = "Selected Image";
      img.style.maxWidth = "100%";
      img.style.display = "block";

      setBase64Image(e.target.result);

      // Append the image to the contenteditable div
      setContent((prevContent) => prevContent + img.outerHTML);
    };
    console.log(base64Image)
    if (file) {
      reader.readAsDataURL(file);
    }
  }

  const postarticle = () => {


    console.log(base64Image)
    console.log(description)
    console.log(blogtitle)
var object = {

userid:"123",
blogtitle:blogtitle,

description:description,
publishdate:"12-12-2012"
}

  };





  return (
    <Box sx={{ flexGrow: 1 }} className='ml-3 mt-3 '>
      <Grid container spacing={2}>
        {/* Main Content */}
        <Grid item xs={12} md={8}> {/* Adjusted to full width on small screens */}
          <Card sx={{ maxWidth: '100%' }} >
            <CardContent >
              <div className='dark:text-white' >

                <button class=" hover:bg-blue-700 hover:text-white font-bold py-2 px-2 mb-2 rounded">
                  <Link href='/'>
                    <CloseRoundedIcon />Cancel
                  </Link>
                </button>
                <div className='display:flex items:center' >

                  <Box
                    sx={{
                      width: 500,
                      maxWidth: '100%',
                    }}
                  >
                    <TextField fullWidth label="Title" id="fullWidth"
                      onChange={handleChange}
                    />

                    <input
                      type="file"
                      id="imageInput"
                      style={{ display: "none" }}
                      onChange={handleImageInsertion}
                    />
                    <button
                      className="mt-2 px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600"
                      onClick={() => document.getElementById('imageInput').click()}
                    >
                      Select Image
                    </button>
                    <div
                      className="border border-gray-300 rounded-lg p-4 mt-5 focus-within:border-blue-300"
                      style={{
                        maxWidth: "60%",
                        minWidth: "85%",
                        minHeight: "36vh"
                      }}

                      dangerouslySetInnerHTML={{ __html: content }}
                    >
                    </div>

                  </Box>
                </div>

                <div className='mt-3 -mx-3 pl-4'>


                  <ToggleButtonGroup
                    value={alignment}
                    exclusive
                    onChange={handleAlignment}
                    aria-label="text alignment"
                  >
                    <ToggleButton value="left" aria-label="left aligned">
                      <FormatAlignLeftIcon />
                      {/* Left */}
                    </ToggleButton>
                    <ToggleButton value="center" aria-label="centered">
                      <FormatAlignCenterIcon />
                      {/* Center */}
                    </ToggleButton>
                    <ToggleButton value="right" aria-label="right aligned">
                      <FormatAlignRightIcon />
                      {/* Right */}
                    </ToggleButton>
                    {/* <ToggleButton value="justify" aria-label="justified" disabled>
  <FormatAlignJustifyIcon />
  Left
</ToggleButton> */}

                    <ToggleButton value="bold" aria-label="bold">
                      <FormatBoldIcon />
                      {/* Bold */}
                    </ToggleButton>
                    <ToggleButton value="italic" aria-label="italic">
                      <FormatItalicIcon />
                      {/* Italian */}
                    </ToggleButton>
                    <ToggleButton value="underlined" aria-label="underlined">
                      <FormatUnderlinedIcon />
                      {/* Underline */}
                    </ToggleButton>
                    <ToggleButton value="color" aria-label="color" disabled>
                      <FormatColorFillIcon />
                      {/* Color */}
                      {/* <ArrowDropDownIcon /> */}
                    </ToggleButton>
                  </ToggleButtonGroup>
                </div>

                <div style={{ marginTop: "-20px" }}>
                  <div
                    class="border border-gray-300 rounded-lg p-4 mt-5 focus-within:border-blue-300"
                    contenteditable="true"
                    style={{
                      maxWidth: "60%",
                      minWidth: " 85%",
                      minHeight: "36vh"

                    }}
                    onInput={handleContentChange}
                    placeholder="Enter your text here..."
                  >
                  </div>

                </div>


              </div>
            </CardContent>
          </Card>
        </Grid>
        {/* Side Panel */}
        <Grid item xs={12} md={4}>
          <Card>
            <CardContent>
              <button onClick={postarticle} class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
                <SendIcon /> Publish
              </button>
              <button class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 ml-3 rounded">
                <DraftsOutlinedIcon /> Draft
              </button>

              <List
                sx={{ width: '100%', maxWidth: 360, bgcolor: 'background.paper' }}
                component="nav"
                aria-labelledby="nested-list-subheader"

              >
                <ListItemButton>

                  <ListItemText primary="Post Settings" />
                </ListItemButton>
                {/* <ListItemButton>
              <ListItemIcon>
                <DraftsIcon />
              </ListItemIcon>
              <ListItemText primary="Drafts" />
            </ListItemButton> */}
                <ListItemButton onClick={handleClick}>
                  <ListItemIcon>
                    <InboxIcon />
                  </ListItemIcon>
                  <ListItemText primary="Published On" />
                  {open ? <ExpandLess /> : <ExpandMore />}
                </ListItemButton>
                <Collapse in={open} timeout="auto" unmountOnExit>
                  <List component="div" disablePadding>
                    <ListItemButton sx={{ pl: 4 }}>
                      <ListItemIcon>


                        <form onSubmit={handleSubmit}>
                          <FormControl sx={{ m: 3 }} error={error} variant="standard">
                            {/* <FormLabel id="demo-error-radios">Pop quiz: MUI is...</FormLabel> */}
                            <RadioGroup
                              aria-labelledby="demo-error-radios"
                              name="quiz"
                              value={value}
                              onChange={handleRadioChange}
                            >
                              <FormControlLabel value="best" control={<Radio />} label="Automatic" />
                              <FormControlLabel value="CustomDate" control={<Radio />} label="Choose Date" />
                            </RadioGroup>
                            <FormHelperText>{helperText}</FormHelperText>
                            <Button sx={{ mt: 1, mr: 1 }} type="submit" variant="outlined">
                              Check Answer
                            </Button>
                          </FormControl>
                        </form>

                      </ListItemIcon>
                    </ListItemButton>
                  </List>
                </Collapse>
              </List>


            </CardContent>
          </Card>
        </Grid>
      </Grid>
    </Box>
  );
}
