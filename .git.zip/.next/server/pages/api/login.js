"use strict";
(() => {
var exports = {};
exports.id = 994;
exports.ids = [994];
exports.modules = {

/***/ 1185:
/***/ ((module) => {

module.exports = require("mongoose");

/***/ }),

/***/ 2897:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ handler)
});

// EXTERNAL MODULE: ./pages/api/db.js
var db = __webpack_require__(5966);
// EXTERNAL MODULE: ./pages/Models/user.js
var Models_user = __webpack_require__(5751);
;// CONCATENATED MODULE: external "bcryptjs"
const external_bcryptjs_namespaceObject = require("bcryptjs");
;// CONCATENATED MODULE: ./pages/api/login.js
// pages/api/login.js
 // Ensure this path is correct
 // Ensure this path is correct

async function handler(req, res) {
    await (0,db["default"])();
    const { method  } = req;
    switch(method){
        case "POST":
            try {
                const { email , password  } = req.body;
                if (!email || !password) {
                    return res.status(400).json({
                        error: "Email and password are required"
                    });
                }
                // const user = await User.findOne({ email });
                const user = await Models_user/* default.findOne */.Z.findOne({
                    email: req.body.email
                });
                if (user) {
                    //check if password matches
                    const result = req.body.password === user.password;
                    if (result) {
                        res.status(200).json({
                            success: true,
                            data: {
                                id: user._id,
                                name: user.name,
                                email: user.email
                            }
                        });
                    }
                }
                if (!user) {
                    return res.status(401).json({
                        error: "Invalid email or password"
                    });
                }
            // const isMatch = await bcrypt.compare(password, user.password);
            // if (!isMatch) {
            //   return res.status(401).json({ error: 'Invalid email or password' });
            // }
            // res.status(200).json({ success: true, data: { id: user._id, name: user.name, email: user.email } });
            } catch (error) {
                console.error("Error logging in:", error);
                res.status(500).json({
                    error: "Server error"
                });
            }
            break;
        default:
            res.setHeader("Allow", [
                "POST"
            ]);
            res.status(405).end(`Method ${method} Not Allowed`);
    }
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [737], () => (__webpack_exec__(2897)));
module.exports = __webpack_exports__;

})();