"use strict";
(() => {
var exports = {};
exports.id = 586;
exports.ids = [586];
exports.modules = {

/***/ 1185:
/***/ ((module) => {

module.exports = require("mongoose");

/***/ }),

/***/ 4271:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var _db__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5966);
/* harmony import */ var _Models_BlogPost__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1748);

 // Ensure the correct path
async function handler(req, res) {
    try {
        await (0,_db__WEBPACK_IMPORTED_MODULE_0__["default"])();
        console.log("Database connected");
        const data = await _Models_BlogPost__WEBPACK_IMPORTED_MODULE_1__/* ["default"].find */ .Z.find();
        if (data.length === 0) {
            console.log("No data found");
            return res.status(404).json({
                message: "No data found for this category"
            });
        }
        console.log("Data retrieved: ", data);
        res.json(data);
    } catch (err) {
        console.error("Error occurred: ", err);
        res.status(500).json({
            message: err.message
        });
    }
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [931], () => (__webpack_exec__(4271)));
module.exports = __webpack_exports__;

})();