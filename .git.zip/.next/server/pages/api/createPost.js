"use strict";
(() => {
var exports = {};
exports.id = 342;
exports.ids = [342];
exports.modules = {

/***/ 1185:
/***/ ((module) => {

module.exports = require("mongoose");

/***/ }),

/***/ 7397:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "config": () => (/* binding */ config),
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var _db__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5966);
/* harmony import */ var _Models_BlogPost__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1748);

 // Ensure the correct path
const config = {
    api: {
        bodyParser: {
            sizeLimit: "10mb"
        }
    }
};
async function handler(req, res) {
    try {
        await (0,_db__WEBPACK_IMPORTED_MODULE_0__["default"])();
        console.log("Database connection established");
        const { method  } = req;
        console.log(`Received ${method} request`);
        debugger;
        switch(method){
            case "POST":
                const { userid , blogtitle , blogdescription , blgIMG_64 , publishdate  } = req.body;
                console.log("Request body:", req.body);
                if (!userid || !blogtitle || !blogdescription || !blgIMG_64 || !publishdate) {
                    console.log("Validation failed");
                    return res.status(400).json({
                        error: "All fields are required"
                    });
                }
                debugger;
                const newPost = new _Models_BlogPost__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z({
                    userid,
                    blogtitle,
                    blogdescription,
                    blgIMG_64,
                    publishdate
                });
                const savedPost = await newPost.save();
                console.log("Post saved:", savedPost);
                res.status(201).json({
                    success: true,
                    data: savedPost
                });
            default:
                res.setHeader("Allow", [
                    "POST"
                ]);
                res.status(405).end(`Method ${method} Not Allowed`);
                break;
        }
    } catch (error) {
        console.error("Database connection error:", error); // Log the error object
        res.status(500).json({
            error: "Database connection error",
            message: error.message
        });
    }
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [931], () => (__webpack_exec__(7397)));
module.exports = __webpack_exports__;

})();