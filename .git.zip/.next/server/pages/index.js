"use strict";
(() => {
var exports = {};
exports.id = 405;
exports.ids = [405];
exports.modules = {

/***/ 6435:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material_Card__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8167);
/* harmony import */ var _mui_material_Card__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Card__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_material_CardActions__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3691);
/* harmony import */ var _mui_material_CardActions__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_material_CardActions__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _mui_material_CardContent__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8455);
/* harmony import */ var _mui_material_CardContent__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_material_CardContent__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _mui_material_CardMedia__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6731);
/* harmony import */ var _mui_material_CardMedia__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_mui_material_CardMedia__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _UserInfoContext__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8800);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9648);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_7__]);
axios__WEBPACK_IMPORTED_MODULE_7__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];










function BlogArticle() {
    const userInfo = (0,_UserInfoContext__WEBPACK_IMPORTED_MODULE_6__/* .useUserInfo */ .P)();
    console.log(userInfo);
    const [allPosts, setAllPosts] = react__WEBPACK_IMPORTED_MODULE_1___default().useState([]);
    const [AllPost, setAllPost] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    // Function to truncate text to a certain number of words
    const truncateText = (text, numWords)=>{
        const words = text.split(" ");
        return words.slice(0, numWords).join(" ") + (words.length > numWords ? "..." : "");
    };
    const loremIpsumText = "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum";
    // get the post 
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        // Fetch all posts when the component mounts
        axios__WEBPACK_IMPORTED_MODULE_7__["default"].get("http://localhost:3000/api/GetAllPosts").then((response)=>{
            setAllPosts(response.data);
        }).catch((error)=>{
            console.error("Error fetching posts:", error);
        });
    }, []); // Empty dependency array means this effect runs once on mount
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            "   ",
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex flex-col md:flex-row p-6 bg-gray-100",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "md:max-w-4xl md:w-4/5 p-6 bg-white md:mr-6 md:mb-0 mb-4",
                        children: allPosts.map((item)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Card__WEBPACK_IMPORTED_MODULE_2___default()), {
                                className: "p-2 mt-3 border-t-2 border-b-2",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                        src: `data:image/jpeg;base64,${item.blgIMG_64}`,
                                        alt: "Image for Blog Article 1",
                                        className: "w-full md:w-1/2 mb-4 rounded-md",
                                        style: {
                                            height: "auto"
                                        }
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_CardContent__WEBPACK_IMPORTED_MODULE_4___default()), {
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                                className: "text-2xl font-bold mb-4",
                                                children: item.blogtitle
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                className: "text-gray-700",
                                                id: "blogdiscription",
                                                children: item.blogdescription
                                            })
                                        ]
                                    })
                                ]
                            }))
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "md:max-w-lg md:w-1/5 p-6 bg-white shadow-md md:mb-0 hidden md:block  ",
                        children: allPosts.map((item)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Card__WEBPACK_IMPORTED_MODULE_2___default()), {
                                className: "p-2 ",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                        src: `data:image/jpeg;base64,${item.blgIMG_64}`,
                                        alt: "Image for Blog Article 2",
                                        className: "mb-4 rounded-md"
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_CardContent__WEBPACK_IMPORTED_MODULE_4___default()), {
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                                className: "text-2xl font-bold mb-4",
                                                children: item.blogtitle
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                className: "text-gray-700",
                                                id: "blogdiscription",
                                                children: item.blogdescription
                                            })
                                        ]
                                    })
                                ]
                            }, item.id))
                    })
                ]
            })
        ]
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (BlogArticle);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2317:
/***/ ((__unused_webpack_module, __unused_webpack___webpack_exports__, __webpack_require__) => {

/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_themes__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1162);
/* harmony import */ var next_themes__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_themes__WEBPACK_IMPORTED_MODULE_2__);



const ThemeChanger = ()=>{
    const [mounted, setMounted] = useState(false);
    const { theme , setTheme  } = useTheme();
    // When mounted on client, now we can show the UI
    useEffect(()=>setMounted(true), []);
    if (!mounted) return null;
    return /*#__PURE__*/ _jsx("div", {
        className: "flex items-center",
        children: theme === "dark" ? /*#__PURE__*/ _jsxs("button", {
            onClick: ()=>setTheme("light"),
            className: "text-gray-300 rounded-full outline-none focus:outline-none",
            children: [
                /*#__PURE__*/ _jsx("span", {
                    className: "sr-only",
                    children: "Light Mode"
                }),
                /*#__PURE__*/ _jsx("svg", {
                    xmlns: "http://www.w3.org/2000/svg",
                    className: "w-5 h-5",
                    viewBox: "0 0 20 20",
                    fill: "currentColor",
                    children: /*#__PURE__*/ _jsx("path", {
                        d: "M17.293 13.293A8 8 0 016.707 2.707a8.001 8.001 0 1010.586 10.586z"
                    })
                })
            ]
        }) : /*#__PURE__*/ _jsxs("button", {
            onClick: ()=>setTheme("dark"),
            className: "text-gray-500 rounded-full outline-none focus:outline-none focus-visible:ring focus-visible:ring-gray-100 focus:ring-opacity-20",
            children: [
                /*#__PURE__*/ _jsx("span", {
                    className: "sr-only",
                    children: "Dark Mode"
                }),
                /*#__PURE__*/ _jsxs("svg", {
                    xmlns: "http://www.w3.org/2000/svg",
                    width: "24",
                    height: "24",
                    viewBox: "0 0 24 24",
                    fill: "none",
                    stroke: "currentColor",
                    strokeWidth: "1",
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    children: [
                        /*#__PURE__*/ _jsx("circle", {
                            cx: "12",
                            cy: "12",
                            r: "5"
                        }),
                        /*#__PURE__*/ _jsx("path", {
                            d: "M12 1v2M12 21v2M4.2 4.2l1.4 1.4M18.4 18.4l1.4 1.4M1 12h2M21 12h2M4.2 19.8l1.4-1.4M18.4 5.6l1.4-1.4"
                        })
                    ]
                })
            ]
        })
    });
};
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (ThemeChanger)));


/***/ }),

/***/ 6513:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ Footer)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: ./components/container.js


const Container = (props)=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: `container p-8 mx-auto xl:px-0 ${props.className ? props.className : ""}`,
        children: props.children
    });
};
/* harmony default export */ const container = (Container);

;// CONCATENATED MODULE: ./components/footer.js





function Footer() {
    const navigation = [
        "Product",
        "Features",
        "Pricing",
        "Company",
        "Blog"
    ];
    const legal = [
        "Terms",
        "Privacy",
        "Legal"
    ];
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "relative",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(container, {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "grid max-w-screen-xl grid-cols-1 gap-10 pt-10 mx-auto mt-5 border-t border-gray-100 dark:border-trueGray-700 lg:grid-cols-5",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "lg:col-span-1"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "flex flex-wrap w-full -mt-2 -ml-3 lg:ml-0",
                                    children: navigation.map((item, index)=>/*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: "/",
                                            className: "w-full px-4 py-2 text-gray-500 rounded-md dark:text-gray-300 hover:text-indigo-500 focus:text-indigo-500 focus:bg-indigo-100 focus:outline-none dark:focus:bg-trueGray-700",
                                            children: item
                                        }, index))
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "flex flex-wrap w-full -mt-2 -ml-3 lg:ml-0",
                                    children: legal.map((item, index)=>/*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: "/",
                                            className: "w-full px-4 py-2 text-gray-500 rounded-md dark:text-gray-300 hover:text-indigo-500 focus:text-indigo-500 focus:bg-indigo-100 focus:outline-none dark:focus:bg-trueGray-700",
                                            children: item
                                        }, index))
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        children: "Follow us"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "flex mt-5 space-x-5 text-gray-400 dark:text-gray-500",
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                                href: "https://twitter.com/web3templates",
                                                target: "_blank",
                                                rel: "noopener",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                        className: "sr-only",
                                                        children: "Twitter"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx(Twitter, {})
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                                href: "https://facebook.com/web3templates",
                                                target: "_blank",
                                                rel: "noopener",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                        className: "sr-only",
                                                        children: "Facebook"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx(Facebook, {})
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                                href: "https://instagram.com/web3templates",
                                                target: "_blank",
                                                rel: "noopener",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                        className: "sr-only",
                                                        children: "Instagram"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx(Instagram, {})
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                                href: "https://linkedin.com/",
                                                target: "_blank",
                                                rel: "noopener",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                        className: "sr-only",
                                                        children: "Linkedin"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx(Linkedin, {})
                                                ]
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "my-10 text-sm text-center text-gray-600 dark:text-gray-400",
                        children: [
                            "Copyright \xa9 ",
                            new Date().getFullYear(),
                            ". Made with ♥ by",
                            " ",
                            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                href: "https://web3templates.com/",
                                target: "_blank",
                                rel: "noopener",
                                children: "Web3Templates."
                            }),
                            " ",
                            "Illustrations from",
                            " ",
                            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                href: "https://www.glazestock.com/",
                                target: "_blank",
                                rel: "noopener ",
                                children: "Glazestock"
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Backlink, {})
        ]
    });
}
const Twitter = ({ size =24  })=>/*#__PURE__*/ jsx_runtime_.jsx("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        width: size,
        height: size,
        viewBox: "0 0 24 24",
        fill: "currentColor",
        children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
            d: "M24 4.37a9.6 9.6 0 0 1-2.83.8 5.04 5.04 0 0 0 2.17-2.8c-.95.58-2 1-3.13 1.22A4.86 4.86 0 0 0 16.61 2a4.99 4.99 0 0 0-4.79 6.2A13.87 13.87 0 0 1 1.67 2.92 5.12 5.12 0 0 0 3.2 9.67a4.82 4.82 0 0 1-2.23-.64v.07c0 2.44 1.7 4.48 3.95 4.95a4.84 4.84 0 0 1-2.22.08c.63 2.01 2.45 3.47 4.6 3.51A9.72 9.72 0 0 1 0 19.74 13.68 13.68 0 0 0 7.55 22c9.06 0 14-7.7 14-14.37v-.65c.96-.71 1.79-1.6 2.45-2.61z"
        })
    });
const Facebook = ({ size =24  })=>/*#__PURE__*/ jsx_runtime_.jsx("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        width: size,
        height: size,
        viewBox: "0 0 24 24",
        fill: "currentColor",
        children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
            d: "M24 12.07C24 5.41 18.63 0 12 0S0 5.4 0 12.07C0 18.1 4.39 23.1 10.13 24v-8.44H7.08v-3.49h3.04V9.41c0-3.02 1.8-4.7 4.54-4.7 1.31 0 2.68.24 2.68.24v2.97h-1.5c-1.5 0-1.96.93-1.96 1.89v2.26h3.32l-.53 3.5h-2.8V24C19.62 23.1 24 18.1 24 12.07"
        })
    });
const Instagram = ({ size =24  })=>/*#__PURE__*/ jsx_runtime_.jsx("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        width: size,
        height: size,
        viewBox: "0 0 24 24",
        fill: "currentColor",
        children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
            d: "M16.98 0a6.9 6.9 0 0 1 5.08 1.98A6.94 6.94 0 0 1 24 7.02v9.96c0 2.08-.68 3.87-1.98 5.13A7.14 7.14 0 0 1 16.94 24H7.06a7.06 7.06 0 0 1-5.03-1.89A6.96 6.96 0 0 1 0 16.94V7.02C0 2.8 2.8 0 7.02 0h9.96zm.05 2.23H7.06c-1.45 0-2.7.43-3.53 1.25a4.82 4.82 0 0 0-1.3 3.54v9.92c0 1.5.43 2.7 1.3 3.58a5 5 0 0 0 3.53 1.25h9.88a5 5 0 0 0 3.53-1.25 4.73 4.73 0 0 0 1.4-3.54V7.02a5 5 0 0 0-1.3-3.49 4.82 4.82 0 0 0-3.54-1.3zM12 5.76c3.39 0 6.2 2.8 6.2 6.2a6.2 6.2 0 0 1-12.4 0 6.2 6.2 0 0 1 6.2-6.2zm0 2.22a3.99 3.99 0 0 0-3.97 3.97A3.99 3.99 0 0 0 12 15.92a3.99 3.99 0 0 0 3.97-3.97A3.99 3.99 0 0 0 12 7.98zm6.44-3.77a1.4 1.4 0 1 1 0 2.8 1.4 1.4 0 0 1 0-2.8z"
        })
    });
const Linkedin = ({ size =24  })=>/*#__PURE__*/ jsx_runtime_.jsx("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        width: size,
        height: size,
        viewBox: "0 0 24 24",
        fill: "currentColor",
        children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
            d: "M22.23 0H1.77C.8 0 0 .77 0 1.72v20.56C0 23.23.8 24 1.77 24h20.46c.98 0 1.77-.77 1.77-1.72V1.72C24 .77 23.2 0 22.23 0zM7.27 20.1H3.65V9.24h3.62V20.1zM5.47 7.76h-.03c-1.22 0-2-.83-2-1.87 0-1.06.8-1.87 2.05-1.87 1.24 0 2 .8 2.02 1.87 0 1.04-.78 1.87-2.05 1.87zM20.34 20.1h-3.63v-5.8c0-1.45-.52-2.45-1.83-2.45-1 0-1.6.67-1.87 1.32-.1.23-.11.55-.11.88v6.05H9.28s.05-9.82 0-10.84h3.63v1.54a3.6 3.6 0 0 1 3.26-1.8c2.39 0 4.18 1.56 4.18 4.89v6.21z"
        })
    });
const Backlink = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
        href: "https://web3templates.com",
        target: "_blank",
        rel: "noopener",
        className: "absolute flex px-3 py-1 space-x-2 text-sm font-semibold text-gray-900 bg-white border border-gray-300 rounded shadow-sm place-items-center left-5 bottom-5 dark:bg-trueGray-900 dark:border-trueGray-700 dark:text-trueGray-300",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
                width: "20",
                height: "20",
                viewBox: "0 0 30 30",
                fill: "none",
                className: "w-4 h-4",
                xmlns: "http://www.w3.org/2000/svg",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("rect", {
                        width: "30",
                        height: "29.5385",
                        rx: "2.76923",
                        fill: "#362F78"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("path", {
                        d: "M10.14 21.94H12.24L15.44 12.18L18.64 21.94H20.74L24.88 8H22.64L19.58 18.68L16.36 8.78H14.52L11.32 18.68L8.24 8H6L10.14 21.94Z",
                        fill: "#F7FAFC"
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                children: "Web3Templates"
            })
        ]
    });
};


/***/ }),

/***/ 636:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _DarkSwitch__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2317);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _headlessui_react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9275);
/* harmony import */ var _mui_icons_material_ModeOutlined__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6330);
/* harmony import */ var _mui_icons_material_ModeOutlined__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_ModeOutlined__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _mui_material_Button__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(3819);
/* harmony import */ var _mui_material_Button__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Button__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _mui_material_Menu__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(8125);
/* harmony import */ var _mui_material_Menu__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Menu__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _mui_material_MenuItem__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(9271);
/* harmony import */ var _mui_material_MenuItem__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_mui_material_MenuItem__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_10__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_headlessui_react__WEBPACK_IMPORTED_MODULE_5__]);
_headlessui_react__WEBPACK_IMPORTED_MODULE_5__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];











const Navbar = ()=>{
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_10__.useRouter)();
    const navigation = [
        "Product",
        "Features",
        "Pricing",
        "Blog",
        "Write"
    ];
    // const [userInfo, setuserInfo] = React.useState();
    const [userInfo, setuserInfo] = react__WEBPACK_IMPORTED_MODULE_1__.useState({});
    const [anchorEl, setAnchorEl] = react__WEBPACK_IMPORTED_MODULE_1__.useState(null);
    const open = Boolean(anchorEl);
    const handleClick = (event)=>{
        setAnchorEl(event.currentTarget);
    };
    const handleClose = ()=>{
        setAnchorEl(null);
    };
    const handleLogout = ()=>{
        setAnchorEl(null);
    };
    react__WEBPACK_IMPORTED_MODULE_1__.useEffect(()=>{
        try {
            const storedInfo = window.localStorage.getItem("loginInfo");
            const userInfoData = storedInfo ? JSON.parse(storedInfo) : {};
            setuserInfo(userInfoData);
        } catch (error) {
            console.error("Error accessing localStorage", error);
        }
    }, []);
    const edditorClikc = ()=>{
        if (userInfo?.data) {
            router.push("/edditor");
        } else {
            router.push("/signin");
        }
    };
    const Logout = ()=>{
        window.localStorage.clear("userInfo");
        window.location.reload();
    };
    console.log(userInfo?.data);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "w-full",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("nav", {
            className: "container relative flex flex-wrap items-center justify-between p-8 mx-auto lg:justify-between xl:px-0",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_headlessui_react__WEBPACK_IMPORTED_MODULE_5__.Disclosure, {
                    children: ({ open  })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex flex-wrap items-center justify-between w-full lg:w-auto",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                        href: "/",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                            className: "flex items-center space-x-2 text-2xl font-medium text-indigo-500 dark:text-gray-100",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                        src: "/img/logo.svg",
                                                        alt: "N",
                                                        width: "32",
                                                        height: "32",
                                                        className: "w-8"
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                    children: "VividVerses"
                                                })
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_headlessui_react__WEBPACK_IMPORTED_MODULE_5__.Disclosure.Button, {
                                        "aria-label": "Toggle Menu",
                                        className: "px-2 py-1 ml-auto text-gray-500 rounded-md lg:hidden hover:text-indigo-500 focus:text-indigo-500 focus:bg-indigo-100 focus:outline-none dark:text-gray-300 dark:focus:bg-trueGray-700",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
                                            className: "w-6 h-6 fill-current",
                                            xmlns: "http://www.w3.org/2000/svg",
                                            viewBox: "0 0 24 24",
                                            children: [
                                                open && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                    fillRule: "evenodd",
                                                    clipRule: "evenodd",
                                                    d: "M18.278 16.864a1 1 0 0 1-1.414 1.414l-4.829-4.828-4.828 4.828a1 1 0 0 1-1.414-1.414l4.828-4.829-4.828-4.828a1 1 0 0 1 1.414-1.414l4.829 4.828 4.828-4.828a1 1 0 1 1 1.414 1.414l-4.828 4.829 4.828 4.828z"
                                                }),
                                                !open && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                    fillRule: "evenodd",
                                                    d: "M4 5h16a1 1 0 0 1 0 2H4a1 1 0 1 1 0-2zm0 6h16a1 1 0 0 1 0 2H4a1 1 0 0 1 0-2zm0 6h16a1 1 0 0 1 0 2H4a1 1 0 0 1 0-2z"
                                                })
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_headlessui_react__WEBPACK_IMPORTED_MODULE_5__.Disclosure.Panel, {
                                        className: "flex flex-wrap w-full my-5 lg:hidden",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                                    href: "/",
                                                    className: "w-full px-4 py-2 -ml-4 text-gray-500 rounded-md dark:text-gray-300 hover:text-indigo-500 focus:text-indigo-500 focus:bg-indigo-100 dark:focus:bg-gray-800 focus:outline-none",
                                                    children: [
                                                        "Write ",
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_ModeOutlined__WEBPACK_IMPORTED_MODULE_6___default()), {})
                                                    ]
                                                }),
                                                userInfo?.data ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                                    href: "",
                                                    onClick: Logout,
                                                    className: " w-full text-center mt-3 px-6 py-2 text-white bg-indigo-600 rounded-md md:ml-5",
                                                    children: "Logout"
                                                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                                    href: "/signin",
                                                    className: " w-full text-center mt-3 px-6 py-2 text-white bg-indigo-600 rounded-md md:ml-5",
                                                    children: "Signin"
                                                })
                                            ]
                                        })
                                    })
                                ]
                            })
                        })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "hidden text-center lg:flex lg:items-center",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                        className: "items-center justify-end flex-1 pt-6 list-none lg:pt-0 lg:flex",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                            className: "mr-3 nav__item",
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                href: "",
                                onClick: edditorClikc,
                                className: "inline-block px-4 py-2 text-lg font-normal text-gray-800 no-underline rounded-md dark:text-gray-200 hover:text-indigo-500 focus:text-indigo-500 focus:bg-indigo-100 focus:outline-none dark:focus:bg-gray-800",
                                children: [
                                    "Write",
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_ModeOutlined__WEBPACK_IMPORTED_MODULE_6___default()), {})
                                ]
                            })
                        })
                    })
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "hidden mr-3 space-x-4 lg:flex nav__item",
                    children: [
                        userInfo?.data ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                            href: "",
                            onClick: Logout,
                            className: "px-6 py-2 text-white bg-indigo-600 rounded-md md:ml-5",
                            children: "Logout"
                        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                            href: "/signin",
                            className: "px-6 py-2 text-white bg-indigo-600 rounded-md md:ml-5",
                            children: "Signin"
                        }),
                        userInfo?.data ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Button__WEBPACK_IMPORTED_MODULE_7___default()), {
                            id: "demo-positioned-button",
                            "aria-controls": open ? "demo-positioned-menu" : undefined,
                            "aria-haspopup": "true",
                            "aria-expanded": open ? "true" : undefined,
                            onClick: handleClick,
                            children: "Info"
                        }) : "",
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Menu__WEBPACK_IMPORTED_MODULE_8___default()), {
                            id: "demo-positioned-menu",
                            "aria-labelledby": "demo-positioned-button",
                            anchorEl: anchorEl,
                            open: open,
                            onClose: handleClose,
                            anchorOrigin: {
                                vertical: "top",
                                horizontal: "left"
                            },
                            transformOrigin: {
                                vertical: "top",
                                horizontal: "left"
                            },
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_MenuItem__WEBPACK_IMPORTED_MODULE_9___default()), {
                                    onClick: handleClose,
                                    children: "Profile"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_MenuItem__WEBPACK_IMPORTED_MODULE_9___default()), {
                                    onClick: handleLogout,
                                    children: "Logout"
                                })
                            ]
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Navbar);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9326:
/***/ ((module, __unused_webpack___webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5641);
/* harmony import */ var _headlessui_react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9275);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_hook_form__WEBPACK_IMPORTED_MODULE_2__, _headlessui_react__WEBPACK_IMPORTED_MODULE_3__]);
([react_hook_form__WEBPACK_IMPORTED_MODULE_2__, _headlessui_react__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);




const PopupWidget = ()=>{
    const { register , handleSubmit , reset , control , formState: { errors , isSubmitSuccessful , isSubmitting  }  } = useForm({
        mode: "onTouched"
    });
    const [isSuccess, setIsSuccess] = useState(false);
    const [Message, setMessage] = useState("");
    const userName = useWatch({
        control,
        name: "name",
        defaultValue: "Someone"
    });
    const onSubmit = async (data, e)=>{
        console.log(data);
        await fetch("https://api.web3forms.com/submit", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                Accept: "application/json"
            },
            body: JSON.stringify(data, null, 2)
        }).then(async (response)=>{
            let json = await response.json();
            if (json.success) {
                setIsSuccess(true);
                setMessage(json.message);
                e.target.reset();
                reset();
            } else {
                setIsSuccess(false);
                setMessage(json.message);
            }
        }).catch((error)=>{
            setIsSuccess(false);
            setMessage("Client Error. Please check the console.log for more info");
            console.log(error);
        });
    };
    return /*#__PURE__*/ _jsx("div", {
        children: /*#__PURE__*/ _jsx(Disclosure, {
            children: ({ open  })=>/*#__PURE__*/ _jsxs(_Fragment, {
                    children: [
                        /*#__PURE__*/ _jsxs(Disclosure.Button, {
                            className: "fixed z-40 flex items-center justify-center transition duration-300 bg-indigo-500 rounded-full shadow-lg right-5 bottom-5 w-14 h-14 focus:outline-none hover:bg-indigo-600 focus:bg-indigo-600 ease",
                            children: [
                                /*#__PURE__*/ _jsx("span", {
                                    className: "sr-only",
                                    children: "Open Contact form Widget"
                                }),
                                /*#__PURE__*/ _jsxs(Transition, {
                                    show: !open,
                                    enter: "transition duration-200 transform ease",
                                    enterFrom: "opacity-0 -rotate-45 scale-75",
                                    leave: "transition duration-100 transform ease",
                                    leaveTo: "opacity-0 -rotate-45",
                                    className: "absolute w-6 h-6 text-white",
                                    children: [
                                        /*#__PURE__*/ _jsx("svg", {
                                            xmlns: "http://www.w3.org/2000/svg",
                                            className: "w-6 h-6",
                                            width: "24",
                                            height: "24",
                                            viewBox: "0 0 24 24",
                                            fill: "none",
                                            stroke: "currentColor",
                                            strokeWidth: "2",
                                            strokeLinecap: "round",
                                            strokeLinejoin: "round",
                                            children: /*#__PURE__*/ _jsx("path", {
                                                d: "M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"
                                            })
                                        }),
                                        " "
                                    ]
                                }),
                                /*#__PURE__*/ _jsxs(Transition, {
                                    show: open,
                                    enter: "transition duration-200 transform ease",
                                    enterFrom: "opacity-0 rotate-45 scale-75",
                                    leave: "transition duration-100 transform ease",
                                    leaveTo: "opacity-0 rotate-45",
                                    className: "absolute w-6 h-6 text-white",
                                    children: [
                                        /*#__PURE__*/ _jsxs("svg", {
                                            xmlns: "http://www.w3.org/2000/svg",
                                            className: "w-6 h-6",
                                            width: "24",
                                            height: "24",
                                            viewBox: "0 0 24 24",
                                            fill: "none",
                                            stroke: "currentColor",
                                            strokeWidth: "2",
                                            strokeLinecap: "round",
                                            strokeLinejoin: "round",
                                            children: [
                                                /*#__PURE__*/ _jsx("line", {
                                                    x1: "18",
                                                    y1: "6",
                                                    x2: "6",
                                                    y2: "18"
                                                }),
                                                /*#__PURE__*/ _jsx("line", {
                                                    x1: "6",
                                                    y1: "6",
                                                    x2: "18",
                                                    y2: "18"
                                                })
                                            ]
                                        }),
                                        " "
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ _jsx(Transition, {
                            className: "fixed  z-50 bottom-[100px] top-0 right-0  left-0 sm:top-auto sm:right-5 sm:left-auto",
                            enter: "transition duration-200 transform ease",
                            enterFrom: "opacity-0 translate-y-5",
                            leave: "transition duration-200 transform ease",
                            leaveTo: "opacity-0 translate-y-5",
                            children: /*#__PURE__*/ _jsxs(Disclosure.Panel, {
                                className: " flex flex-col  overflow-hidden left-0 h-full w-full sm:w-[350px] min-h-[250px] sm:h-[600px] border border-gray-300 dark:border-gray-800 bg-white shadow-2xl rounded-md sm:max-h-[calc(100vh-120px)]",
                                children: [
                                    /*#__PURE__*/ _jsxs("div", {
                                        className: "flex flex-col items-center justify-center h-32 p-5 bg-indigo-600",
                                        children: [
                                            /*#__PURE__*/ _jsx("h3", {
                                                className: "text-lg text-white",
                                                children: "How can we help?"
                                            }),
                                            /*#__PURE__*/ _jsx("p", {
                                                className: "text-white opacity-50",
                                                children: "We usually respond in a few hours"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ _jsxs("div", {
                                        className: "flex-grow h-full p-6 overflow-auto bg-gray-50 ",
                                        children: [
                                            !isSubmitSuccessful && /*#__PURE__*/ _jsxs("form", {
                                                onSubmit: handleSubmit(onSubmit),
                                                noValidate: true,
                                                children: [
                                                    /*#__PURE__*/ _jsx("input", {
                                                        type: "hidden",
                                                        value: "YOUR_ACCESS_KEY_HERE",
                                                        ...register("apikey")
                                                    }),
                                                    /*#__PURE__*/ _jsx("input", {
                                                        type: "hidden",
                                                        value: `${userName} sent a message from Nextly`,
                                                        ...register("subject")
                                                    }),
                                                    /*#__PURE__*/ _jsx("input", {
                                                        type: "hidden",
                                                        value: "Nextly Template",
                                                        ...register("from_name")
                                                    }),
                                                    /*#__PURE__*/ _jsx("input", {
                                                        type: "checkbox",
                                                        className: "hidden",
                                                        style: {
                                                            display: "none"
                                                        },
                                                        ...register("botcheck")
                                                    }),
                                                    /*#__PURE__*/ _jsxs("div", {
                                                        className: "mb-4",
                                                        children: [
                                                            /*#__PURE__*/ _jsx("label", {
                                                                htmlFor: "full_name",
                                                                className: "block mb-2 text-sm text-gray-600 dark:text-gray-400",
                                                                children: "Full Name"
                                                            }),
                                                            /*#__PURE__*/ _jsx("input", {
                                                                type: "text",
                                                                id: "full_name",
                                                                placeholder: "John Doe",
                                                                ...register("name", {
                                                                    required: "Full name is required",
                                                                    maxLength: 80
                                                                }),
                                                                className: `w-full px-3 py-2 text-gray-600 placeholder-gray-300 bg-white border border-gray-300 rounded-md focus:outline-none focus:ring   ${errors.name ? "border-red-600 focus:border-red-600 ring-red-100" : "border-gray-300 focus:border-indigo-600 ring-indigo-100"}`
                                                            }),
                                                            errors.name && /*#__PURE__*/ _jsx("div", {
                                                                className: "mt-1 text-sm text-red-400 invalid-feedback",
                                                                children: errors.name.message
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ _jsxs("div", {
                                                        className: "mb-4",
                                                        children: [
                                                            /*#__PURE__*/ _jsx("label", {
                                                                htmlFor: "email",
                                                                className: "block mb-2 text-sm text-gray-600 dark:text-gray-400",
                                                                children: "Email Address"
                                                            }),
                                                            /*#__PURE__*/ _jsx("input", {
                                                                type: "email",
                                                                id: "email",
                                                                ...register("email", {
                                                                    required: "Enter your email",
                                                                    pattern: {
                                                                        value: /^\S+@\S+$/i,
                                                                        message: "Please enter a valid email"
                                                                    }
                                                                }),
                                                                placeholder: "you@company.com",
                                                                className: `w-full px-3 py-2 text-gray-600 placeholder-gray-300 bg-white border border-gray-300 rounded-md focus:outline-none focus:ring   ${errors.email ? "border-red-600 focus:border-red-600 ring-red-100" : "border-gray-300 focus:border-indigo-600 ring-indigo-100"}`
                                                            }),
                                                            errors.email && /*#__PURE__*/ _jsx("div", {
                                                                className: "mt-1 text-sm text-red-400 invalid-feedback",
                                                                children: errors.email.message
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ _jsxs("div", {
                                                        className: "mb-4",
                                                        children: [
                                                            /*#__PURE__*/ _jsx("label", {
                                                                htmlFor: "message",
                                                                className: "block mb-2 text-sm text-gray-600 dark:text-gray-400",
                                                                children: "Your Message"
                                                            }),
                                                            /*#__PURE__*/ _jsx("textarea", {
                                                                rows: "4",
                                                                id: "message",
                                                                ...register("message", {
                                                                    required: "Enter your Message"
                                                                }),
                                                                placeholder: "Your Message",
                                                                className: `w-full px-3 py-2 text-gray-600 placeholder-gray-300 bg-white border border-gray-300 rounded-md h-28 focus:outline-none focus:ring   ${errors.message ? "border-red-600 focus:border-red-600 ring-red-100" : "border-gray-300 focus:border-indigo-600 ring-indigo-100"}`,
                                                                required: true
                                                            }),
                                                            errors.message && /*#__PURE__*/ _jsx("div", {
                                                                className: "mt-1 text-sm text-red-400 invalid-feedback",
                                                                children: errors.message.message
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ _jsx("div", {
                                                        className: "mb-3",
                                                        children: /*#__PURE__*/ _jsx("button", {
                                                            type: "submit",
                                                            className: "w-full px-3 py-4 text-white bg-indigo-500 rounded-md focus:bg-indigo-600 focus:outline-none",
                                                            children: isSubmitting ? /*#__PURE__*/ _jsxs("svg", {
                                                                className: "w-5 h-5 mx-auto text-white animate-spin",
                                                                xmlns: "http://www.w3.org/2000/svg",
                                                                fill: "none",
                                                                viewBox: "0 0 24 24",
                                                                children: [
                                                                    /*#__PURE__*/ _jsx("circle", {
                                                                        className: "opacity-25",
                                                                        cx: "12",
                                                                        cy: "12",
                                                                        r: "10",
                                                                        stroke: "currentColor",
                                                                        strokeWidth: "4"
                                                                    }),
                                                                    /*#__PURE__*/ _jsx("path", {
                                                                        className: "opacity-75",
                                                                        fill: "currentColor",
                                                                        d: "M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                                                                    })
                                                                ]
                                                            }) : "Send Message"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ _jsx("p", {
                                                        className: "text-xs text-center text-gray-400",
                                                        id: "result",
                                                        children: /*#__PURE__*/ _jsxs("span", {
                                                            children: [
                                                                "Powered by",
                                                                " ",
                                                                /*#__PURE__*/ _jsx("a", {
                                                                    href: "https://Web3Forms.com",
                                                                    className: "text-gray-600",
                                                                    target: "_blank",
                                                                    rel: "noopener noreferrer",
                                                                    children: "Web3Forms"
                                                                })
                                                            ]
                                                        })
                                                    })
                                                ]
                                            }),
                                            isSubmitSuccessful && isSuccess && /*#__PURE__*/ _jsx(_Fragment, {
                                                children: /*#__PURE__*/ _jsxs("div", {
                                                    className: "flex flex-col items-center justify-center h-full text-center text-white rounded-md",
                                                    children: [
                                                        /*#__PURE__*/ _jsx("svg", {
                                                            width: "60",
                                                            height: "60",
                                                            className: "text-green-300",
                                                            viewBox: "0 0 100 100",
                                                            fill: "none",
                                                            xmlns: "http://www.w3.org/2000/svg",
                                                            children: /*#__PURE__*/ _jsx("path", {
                                                                d: "M26.6666 50L46.6666 66.6667L73.3333 33.3333M50 96.6667C43.8716 96.6667 37.8033 95.4596 32.1414 93.1144C26.4796 90.7692 21.3351 87.3317 17.0017 82.9983C12.6683 78.6649 9.23082 73.5204 6.8856 67.8586C4.54038 62.1967 3.33331 56.1283 3.33331 50C3.33331 43.8716 4.54038 37.8033 6.8856 32.1414C9.23082 26.4796 12.6683 21.3351 17.0017 17.0017C21.3351 12.6683 26.4796 9.23084 32.1414 6.88562C37.8033 4.5404 43.8716 3.33333 50 3.33333C62.3767 3.33333 74.2466 8.24998 82.9983 17.0017C91.75 25.7534 96.6666 37.6232 96.6666 50C96.6666 62.3768 91.75 74.2466 82.9983 82.9983C74.2466 91.75 62.3767 96.6667 50 96.6667Z",
                                                                stroke: "currentColor",
                                                                strokeWidth: "3"
                                                            })
                                                        }),
                                                        /*#__PURE__*/ _jsx("h3", {
                                                            className: "py-5 text-xl text-green-500",
                                                            children: "Message sent successfully"
                                                        }),
                                                        /*#__PURE__*/ _jsx("p", {
                                                            className: "text-gray-700 md:px-3",
                                                            children: Message
                                                        }),
                                                        /*#__PURE__*/ _jsx("button", {
                                                            className: "mt-6 text-indigo-600 focus:outline-none",
                                                            onClick: ()=>reset(),
                                                            children: "Go back"
                                                        })
                                                    ]
                                                })
                                            }),
                                            isSubmitSuccessful && !isSuccess && /*#__PURE__*/ _jsxs("div", {
                                                className: "flex flex-col items-center justify-center h-full text-center text-white rounded-md",
                                                children: [
                                                    /*#__PURE__*/ _jsx("svg", {
                                                        width: "60",
                                                        height: "60",
                                                        viewBox: "0 0 97 97",
                                                        className: "text-red-400",
                                                        fill: "none",
                                                        xmlns: "http://www.w3.org/2000/svg",
                                                        children: /*#__PURE__*/ _jsx("path", {
                                                            d: "M27.9995 69C43.6205 53.379 52.3786 44.621 67.9995 29M26.8077 29L67.9995 69M48.2189 95C42.0906 95 36.0222 93.7929 30.3604 91.4477C24.6985 89.1025 19.554 85.6651 15.2206 81.3316C10.8872 76.9982 7.44975 71.8538 5.10454 66.1919C2.75932 60.53 1.55225 54.4617 1.55225 48.3333C1.55225 42.205 2.75932 36.1366 5.10454 30.4748C7.44975 24.8129 10.8872 19.6684 15.2206 15.335C19.554 11.0016 24.6985 7.56418 30.3604 5.21896C36.0222 2.87374 42.0906 1.66667 48.2189 1.66667C60.5957 1.66667 72.4655 6.58333 81.2172 15.335C89.9689 24.0867 94.8856 35.9566 94.8856 48.3333C94.8856 60.7101 89.9689 72.58 81.2172 81.3316C72.4655 90.0833 60.5957 95 48.2189 95Z",
                                                            stroke: "CurrentColor",
                                                            strokeWidth: "3"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ _jsx("h3", {
                                                        className: "text-xl text-red-400 py-7",
                                                        children: "Oops, Something went wrong!"
                                                    }),
                                                    /*#__PURE__*/ _jsx("p", {
                                                        className: "text-gray-700 md:px-3",
                                                        children: Message
                                                    }),
                                                    /*#__PURE__*/ _jsx("button", {
                                                        className: "mt-6 text-indigo-600 focus:outline-none",
                                                        onClick: ()=>reset(),
                                                        children: "Go back"
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                ]
                            })
                        })
                    ]
                })
        })
    });
};
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (PopupWidget)));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6616:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(968);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_navbar__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(636);
/* harmony import */ var _components_footer__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6513);
/* harmony import */ var _components_popupWidget__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9326);
/* harmony import */ var _components_Blogarticle__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6435);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_navbar__WEBPACK_IMPORTED_MODULE_2__, _components_popupWidget__WEBPACK_IMPORTED_MODULE_4__, _components_Blogarticle__WEBPACK_IMPORTED_MODULE_5__]);
([_components_navbar__WEBPACK_IMPORTED_MODULE_2__, _components_popupWidget__WEBPACK_IMPORTED_MODULE_4__, _components_Blogarticle__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);






const Home = ()=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_navbar__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Blogarticle__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_footer__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {})
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Home);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6330:
/***/ ((module) => {

module.exports = require("@mui/icons-material/ModeOutlined");

/***/ }),

/***/ 3819:
/***/ ((module) => {

module.exports = require("@mui/material/Button");

/***/ }),

/***/ 8167:
/***/ ((module) => {

module.exports = require("@mui/material/Card");

/***/ }),

/***/ 3691:
/***/ ((module) => {

module.exports = require("@mui/material/CardActions");

/***/ }),

/***/ 8455:
/***/ ((module) => {

module.exports = require("@mui/material/CardContent");

/***/ }),

/***/ 6731:
/***/ ((module) => {

module.exports = require("@mui/material/CardMedia");

/***/ }),

/***/ 8125:
/***/ ((module) => {

module.exports = require("@mui/material/Menu");

/***/ }),

/***/ 9271:
/***/ ((module) => {

module.exports = require("@mui/material/MenuItem");

/***/ }),

/***/ 1162:
/***/ ((module) => {

module.exports = require("next-themes");

/***/ }),

/***/ 3918:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 5732:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 3539:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/detect-domain-locale.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 4486:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 9552:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 3431:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-locale.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 1109:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 7782:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 2470:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 618:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 9275:
/***/ ((module) => {

module.exports = import("@headlessui/react");;

/***/ }),

/***/ 9648:
/***/ ((module) => {

module.exports = import("axios");;

/***/ }),

/***/ 5641:
/***/ ((module) => {

module.exports = import("react-hook-form");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [664,636,260,800], () => (__webpack_exec__(6616)));
module.exports = __webpack_exports__;

})();