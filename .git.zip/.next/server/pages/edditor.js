"use strict";
(() => {
var exports = {};
exports.id = 71;
exports.ids = [71];
exports.modules = {

/***/ 2372:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ CustomizedDividers)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9648);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8442);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_material_styles__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _mui_material_Box__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(19);
/* harmony import */ var _mui_material_Box__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Box__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _mui_material_Paper__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1598);
/* harmony import */ var _mui_material_Paper__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Paper__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _mui_material_Grid__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5612);
/* harmony import */ var _mui_material_Grid__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Grid__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _mui_material_Card__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8167);
/* harmony import */ var _mui_material_Card__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Card__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _mui_material_CardContent__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(8455);
/* harmony import */ var _mui_material_CardContent__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_mui_material_CardContent__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _mui_material_TextField__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(6042);
/* harmony import */ var _mui_material_TextField__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_mui_material_TextField__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _mui_material_Button__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(3819);
/* harmony import */ var _mui_material_Button__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Button__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _mui_material_ToggleButton__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(6781);
/* harmony import */ var _mui_material_ToggleButton__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_mui_material_ToggleButton__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _mui_material_ToggleButtonGroup__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(5951);
/* harmony import */ var _mui_material_ToggleButtonGroup__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(_mui_material_ToggleButtonGroup__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var _mui_icons_material_FormatBold__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(5403);
/* harmony import */ var _mui_icons_material_FormatBold__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_FormatBold__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var _mui_icons_material_FormatItalic__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(9422);
/* harmony import */ var _mui_icons_material_FormatItalic__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_FormatItalic__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var _mui_icons_material_FormatUnderlined__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(7609);
/* harmony import */ var _mui_icons_material_FormatUnderlined__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_FormatUnderlined__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var _mui_icons_material_FormatAlignLeft__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(1893);
/* harmony import */ var _mui_icons_material_FormatAlignLeft__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_FormatAlignLeft__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var _mui_icons_material_FormatAlignCenter__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(4049);
/* harmony import */ var _mui_icons_material_FormatAlignCenter__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_FormatAlignCenter__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var _mui_icons_material_FormatAlignRight__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(8888);
/* harmony import */ var _mui_icons_material_FormatAlignRight__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_FormatAlignRight__WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var _mui_icons_material_FormatColorFill__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(764);
/* harmony import */ var _mui_icons_material_FormatColorFill__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_FormatColorFill__WEBPACK_IMPORTED_MODULE_19__);
/* harmony import */ var _mui_icons_material_ArrowDropDown__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(765);
/* harmony import */ var _mui_icons_material_ArrowDropDown__WEBPACK_IMPORTED_MODULE_20___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_ArrowDropDown__WEBPACK_IMPORTED_MODULE_20__);
/* harmony import */ var _mui_icons_material_CloseRounded__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(4317);
/* harmony import */ var _mui_icons_material_CloseRounded__WEBPACK_IMPORTED_MODULE_21___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_CloseRounded__WEBPACK_IMPORTED_MODULE_21__);
/* harmony import */ var _mui_icons_material_Send__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(4731);
/* harmony import */ var _mui_icons_material_Send__WEBPACK_IMPORTED_MODULE_22___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Send__WEBPACK_IMPORTED_MODULE_22__);
/* harmony import */ var _mui_icons_material_DraftsOutlined__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(984);
/* harmony import */ var _mui_icons_material_DraftsOutlined__WEBPACK_IMPORTED_MODULE_23___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_DraftsOutlined__WEBPACK_IMPORTED_MODULE_23__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_24___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_24__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_25___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_25__);
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(2947);
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_26___default = /*#__PURE__*/__webpack_require__.n(jquery__WEBPACK_IMPORTED_MODULE_26__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_2__]);
axios__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



























function CustomizedDividers() {
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_24__.useRouter)();
    const [base64Image, setBase64Image] = react__WEBPACK_IMPORTED_MODULE_1__.useState("");
    const [content, setContent] = react__WEBPACK_IMPORTED_MODULE_1__.useState("");
    const [blogtitle, setBlogTitle] = react__WEBPACK_IMPORTED_MODULE_1__.useState("");
    const [description, setDescription] = react__WEBPACK_IMPORTED_MODULE_1__.useState("");
    const [alignment, setAlignment] = react__WEBPACK_IMPORTED_MODULE_1__.useState("left");
    const [open, setOpen] = react__WEBPACK_IMPORTED_MODULE_1__.useState(false);
    const handleChange = (e)=>{
        const { name , value  } = e.target;
        if (name === "blogtitle") setBlogTitle(value);
    };
    const handleContentChange = (event)=>{
        setDescription(event.target.innerHTML);
    };
    const handleImageInsertion = (event)=>{
        const file = event.target.files[0];
        const reader = new FileReader();
        reader.onload = function(e) {
            setBase64Image(e.target.result);
            setContent((prevContent)=>prevContent + `<img src="${e.target.result}" alt="Selected Image" style="max-width: 100%; display: block;" />`);
        };
        if (file) reader.readAsDataURL(file);
    };
    const handleAlignment = (event, newAlignment)=>{
        setAlignment(newAlignment);
    };
    const handleClick = ()=>{
        setOpen(!open);
    };
    const postArticle = async ()=>{
        const currentDate = new Date();
        const formattedDateTime = formatDateTime(currentDate);
        const base64Imagewe = base64Image.split(",")[1];
        const userId = "2138676b-462c-48ed-74f0-08db9d5e5ff3";
        const object = {
            userid: userId,
            blogtitle: blogtitle,
            blogdescription: description,
            blgIMG_64: base64Imagewe,
            publishdate: formattedDateTime
        };
        try {
            const response = await axios__WEBPACK_IMPORTED_MODULE_2__["default"].post("http://localhost:3000/api/createPost", object);
            console.log("Response:", response.data);
            router.push("/");
        } catch (error) {
            console.error("Error:", error.response ? error.response.data : error.message);
        }
    };
    // const postArticle = async () => {
    //   const currentDate = new Date();
    //   const formattedDateTime = formatDateTime(currentDate);
    //   const base64Imagewe = base64Image.split(",")[1];
    //   const userId = '2138676b-462c-48ed-74f0-08db9d5e5ff3';
    //   const object = {
    //     userid: userId,
    //     blogtitle: blogtitle,
    //     blogdescription: description,
    //     blgIMG_64: base64Imagewe,
    //     publishdate: formattedDateTime,
    //   };
    //   // try {
    //   //   const response = await axios.post('http://localhost:3000/api/createPost', object);
    //   //   console.log('Response:', response.data);
    //   // } catch (error) {
    //   //   console.error('Error:', error.response ? error.response.data : error.message);
    //   // }
    //   // Call this method to add new data to bibliography
    //   axios.post('http://localhost:3000/api/createPost',object)
    //     .then(response => {
    //       console.log('Response:', response);
    //     //  router.push('/signin');
    //     })
    //     .catch(error => {
    //       console.error('Error:', error);
    //      // setError('Something went wrong. Please try again.');
    //     });
    // //   var settings = {
    // //     url:"http://localhost:3000/api/createPost",
    // //     method: "POST",
    // //     contentType: "application/json",
    // //     data: JSON.stringify(
    // //       {
    // //          userId,
    // //          blogtitle,
    // //          description,
    // //          base64Imagewe,
    // //          formattedDateTime,
    // //       })
    // // };
    // // $.ajax(settings).done(function (response) {
    // //     console.log(null, response);
    // // }).fail(function (xhr) {
    // //     let errorMessage;
    // //     // Check the status code and set an appropriate error message
    // //     switch (xhr.status) {
    // //         case 400:
    // //             errorMessage = '400 Bad Request: unable to understand request.';
    // //             break;
    // //         case 401:
    // //             errorMessage = '401 Unauthorized: invalid credentials.';
    // //             break;
    // //         case 403:
    // //             errorMessage = '403 Forbidden: Method not allowed';
    // //             break;
    // //         case 404:
    // //             errorMessage = '404 Not Found: resource not found.';
    // //             break;
    // //         case 500:
    // //             errorMessage = '500 Internal Server Error';
    // //             break;
    // //         case 503:
    // //             errorMessage = '503 Service Unavailable: unable to handle request.';
    // //             break;
    // //         default:
    // //             errorMessage = `An error occurred: ${xhr.status} ${xhr.statusText}`;
    // //     }})
    // };
    function formatDateTime(date) {
        const year = date.getFullYear();
        const month = String(date.getMonth() + 1).padStart(2, "0");
        const day = String(date.getDate()).padStart(2, "0");
        const hours = String(date.getHours()).padStart(2, "0");
        const minutes = String(date.getMinutes()).padStart(2, "0");
        const seconds = String(date.getSeconds()).padStart(2, "0");
        const milliseconds = String(date.getMilliseconds()).padStart(3, "0");
        return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}.${milliseconds}`;
    }
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Box__WEBPACK_IMPORTED_MODULE_4___default()), {
        sx: {
            flexGrow: 1
        },
        className: "ml-3 mt-3 ",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_6___default()), {
            container: true,
            spacing: 2,
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_6___default()), {
                    item: true,
                    xs: 12,
                    md: 8,
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Card__WEBPACK_IMPORTED_MODULE_7___default()), {
                        sx: {
                            maxWidth: "100%"
                        },
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_CardContent__WEBPACK_IMPORTED_MODULE_8___default()), {
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "dark:text-white",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                        className: "hover:bg-blue-700 hover:text-white font-bold py-2 px-2 mb-2 rounded",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_25___default()), {
                                            href: "/",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_CloseRounded__WEBPACK_IMPORTED_MODULE_21___default()), {}),
                                                "Cancel"
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "display:flex items:center",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Box__WEBPACK_IMPORTED_MODULE_4___default()), {
                                            sx: {
                                                width: 500,
                                                maxWidth: "100%"
                                            },
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TextField__WEBPACK_IMPORTED_MODULE_9___default()), {
                                                    fullWidth: true,
                                                    label: "Title",
                                                    id: "fullWidth",
                                                    name: "blogtitle",
                                                    onChange: handleChange
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                    type: "file",
                                                    id: "imageInput",
                                                    style: {
                                                        display: "none"
                                                    },
                                                    onChange: handleImageInsertion
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                    className: "mt-2 px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600",
                                                    onClick: ()=>document.getElementById("imageInput").click(),
                                                    children: "Select Image"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "border border-gray-300 rounded-lg p-4 mt-5 focus-within:border-blue-300",
                                                    style: {
                                                        maxWidth: "60%",
                                                        minWidth: "85%",
                                                        minHeight: "36vh"
                                                    },
                                                    dangerouslySetInnerHTML: {
                                                        __html: content
                                                    }
                                                })
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "mt-3 -mx-3 pl-4",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_ToggleButtonGroup__WEBPACK_IMPORTED_MODULE_12___default()), {
                                            value: alignment,
                                            exclusive: true,
                                            onChange: handleAlignment,
                                            "aria-label": "text alignment",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_ToggleButton__WEBPACK_IMPORTED_MODULE_11___default()), {
                                                    value: "left",
                                                    "aria-label": "left aligned",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_FormatAlignLeft__WEBPACK_IMPORTED_MODULE_16___default()), {})
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_ToggleButton__WEBPACK_IMPORTED_MODULE_11___default()), {
                                                    value: "center",
                                                    "aria-label": "centered",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_FormatAlignCenter__WEBPACK_IMPORTED_MODULE_17___default()), {})
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_ToggleButton__WEBPACK_IMPORTED_MODULE_11___default()), {
                                                    value: "right",
                                                    "aria-label": "right aligned",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_FormatAlignRight__WEBPACK_IMPORTED_MODULE_18___default()), {})
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_ToggleButton__WEBPACK_IMPORTED_MODULE_11___default()), {
                                                    value: "bold",
                                                    "aria-label": "bold",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_FormatBold__WEBPACK_IMPORTED_MODULE_13___default()), {})
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_ToggleButton__WEBPACK_IMPORTED_MODULE_11___default()), {
                                                    value: "italic",
                                                    "aria-label": "italic",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_FormatItalic__WEBPACK_IMPORTED_MODULE_14___default()), {})
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_ToggleButton__WEBPACK_IMPORTED_MODULE_11___default()), {
                                                    value: "underlined",
                                                    "aria-label": "underlined",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_FormatUnderlined__WEBPACK_IMPORTED_MODULE_15___default()), {})
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_ToggleButton__WEBPACK_IMPORTED_MODULE_11___default()), {
                                                    value: "color",
                                                    "aria-label": "color",
                                                    disabled: true,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_FormatColorFill__WEBPACK_IMPORTED_MODULE_19___default()), {})
                                                })
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        style: {
                                            marginTop: "-20px"
                                        },
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "border border-gray-300 rounded-lg p-4 mt-5 focus-within:border-blue-300",
                                            contentEditable: "true",
                                            style: {
                                                maxWidth: "60%",
                                                minWidth: " 85%",
                                                minHeight: "36vh"
                                            },
                                            onInput: handleContentChange,
                                            placeholder: "Enter your text here..."
                                        })
                                    })
                                ]
                            })
                        })
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_6___default()), {
                    item: true,
                    xs: 12,
                    md: 4,
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Card__WEBPACK_IMPORTED_MODULE_7___default()), {
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_CardContent__WEBPACK_IMPORTED_MODULE_8___default()), {
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                                    onClick: postArticle,
                                    className: "bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Send__WEBPACK_IMPORTED_MODULE_22___default()), {}),
                                        " Publish"
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                                    className: "bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 ml-3 rounded",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_DraftsOutlined__WEBPACK_IMPORTED_MODULE_23___default()), {}),
                                        " Draft"
                                    ]
                                })
                            ]
                        })
                    })
                })
            ]
        })
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 765:
/***/ ((module) => {

module.exports = require("@mui/icons-material/ArrowDropDown");

/***/ }),

/***/ 4317:
/***/ ((module) => {

module.exports = require("@mui/icons-material/CloseRounded");

/***/ }),

/***/ 984:
/***/ ((module) => {

module.exports = require("@mui/icons-material/DraftsOutlined");

/***/ }),

/***/ 4049:
/***/ ((module) => {

module.exports = require("@mui/icons-material/FormatAlignCenter");

/***/ }),

/***/ 1893:
/***/ ((module) => {

module.exports = require("@mui/icons-material/FormatAlignLeft");

/***/ }),

/***/ 8888:
/***/ ((module) => {

module.exports = require("@mui/icons-material/FormatAlignRight");

/***/ }),

/***/ 5403:
/***/ ((module) => {

module.exports = require("@mui/icons-material/FormatBold");

/***/ }),

/***/ 764:
/***/ ((module) => {

module.exports = require("@mui/icons-material/FormatColorFill");

/***/ }),

/***/ 9422:
/***/ ((module) => {

module.exports = require("@mui/icons-material/FormatItalic");

/***/ }),

/***/ 7609:
/***/ ((module) => {

module.exports = require("@mui/icons-material/FormatUnderlined");

/***/ }),

/***/ 4731:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Send");

/***/ }),

/***/ 19:
/***/ ((module) => {

module.exports = require("@mui/material/Box");

/***/ }),

/***/ 3819:
/***/ ((module) => {

module.exports = require("@mui/material/Button");

/***/ }),

/***/ 8167:
/***/ ((module) => {

module.exports = require("@mui/material/Card");

/***/ }),

/***/ 8455:
/***/ ((module) => {

module.exports = require("@mui/material/CardContent");

/***/ }),

/***/ 5612:
/***/ ((module) => {

module.exports = require("@mui/material/Grid");

/***/ }),

/***/ 1598:
/***/ ((module) => {

module.exports = require("@mui/material/Paper");

/***/ }),

/***/ 6042:
/***/ ((module) => {

module.exports = require("@mui/material/TextField");

/***/ }),

/***/ 6781:
/***/ ((module) => {

module.exports = require("@mui/material/ToggleButton");

/***/ }),

/***/ 5951:
/***/ ((module) => {

module.exports = require("@mui/material/ToggleButtonGroup");

/***/ }),

/***/ 8442:
/***/ ((module) => {

module.exports = require("@mui/material/styles");

/***/ }),

/***/ 2947:
/***/ ((module) => {

module.exports = require("jquery");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 3539:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/detect-domain-locale.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 3431:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-locale.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 1109:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 7782:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 9648:
/***/ ((module) => {

module.exports = import("axios");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [664], () => (__webpack_exec__(2372)));
module.exports = __webpack_exports__;

})();