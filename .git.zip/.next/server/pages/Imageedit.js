"use strict";
(() => {
var exports = {};
exports.id = 831;
exports.ids = [831];
exports.modules = {

/***/ 9182:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ pages_Imageedit)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
;// CONCATENATED MODULE: external "react-resizable"
const external_react_resizable_namespaceObject = require("react-resizable");
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: ./pages/Imageedit.js



const Imageedit = ()=>{
    const [content, setContent] = external_react_.useState("");
    // Function to handle image insertion
    function handleImageInsertion(event) {
        const file = event.target.files[0];
        const reader = new FileReader();
        reader.onload = function(e) {
            const imgSrc = e.target.result;
            const img = new Image();
            img.src = imgSrc;
            img.alt = "Selected Image";
            // Wrap the image with a resizable container
            const resizableImg = /*#__PURE__*/ jsx_runtime_.jsx(external_react_resizable_namespaceObject.Resizable, {
                width: 200,
                height: 200,
                style: {
                    position: "relative",
                    overflow: "hidden"
                },
                children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                    src: imgSrc,
                    alt: "Selected Image"
                })
            }, imgSrc);
            // Append the resizable image container to the contenteditable div
            setContent((prevContent)=>prevContent + resizableImg);
        };
        if (file) {
            reader.readAsDataURL(file);
        }
    }
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "border border-gray-300 rounded-lg p-4 mt-5 focus-within:border-blue-300",
                contentEditable: true,
                style: {
                    maxWidth: "60%",
                    minWidth: "85%",
                    minHeight: "36vh"
                },
                placeholder: "Enter your text here...",
                dangerouslySetInnerHTML: {
                    __html: content
                }
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("input", {
                        type: "file",
                        id: "imageInput",
                        style: {
                            display: "none"
                        },
                        onChange: handleImageInsertion
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                        className: "mt-2 px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600",
                        onClick: ()=>document.getElementById("imageInput").click(),
                        children: "Select Image"
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const pages_Imageedit = (Imageedit);


/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(9182));
module.exports = __webpack_exports__;

})();