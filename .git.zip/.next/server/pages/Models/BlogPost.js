"use strict";
(() => {
var exports = {};
exports.id = 747;
exports.ids = [747];
exports.modules = {

/***/ 8032:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1185);
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mongoose__WEBPACK_IMPORTED_MODULE_0__);

const BlogPostSchema = new (mongoose__WEBPACK_IMPORTED_MODULE_0___default().Schema)({
    userid: {
        type: String
    },
    blogtitle: {
        type: String,
        required: true
    },
    blogdescription: {
        type: String,
        required: true
    },
    blgIMG_64: {
        type: String,
        required: true
    },
    publishdate: {
        type: String,
        required: true
    }
}, {
    timestamps: true
});
const BlogPost = (mongoose__WEBPACK_IMPORTED_MODULE_0___default().models.BlogPost) || mongoose__WEBPACK_IMPORTED_MODULE_0___default().model("BlogPost", BlogPostSchema);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (BlogPost);


/***/ }),

/***/ 1185:
/***/ ((module) => {

module.exports = require("mongoose");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(8032));
module.exports = __webpack_exports__;

})();