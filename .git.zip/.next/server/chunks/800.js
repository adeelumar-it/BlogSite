"use strict";
exports.id = 800;
exports.ids = [800];
exports.modules = {

/***/ 8800:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "P": () => (/* binding */ useUserInfo)
/* harmony export */ });
/* unused harmony export UserInfoProvider */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
// // components/UserInfoContext.js
// import React, { createContext, useContext, useEffect, useState } from 'react';
// const UserInfoContext = createContext();
// export const UserInfoProvider = ({ children }) => {
//   const [userInfo, setUserInfo] = useState(null);
//   useEffect(() => {
//     const storedUserInfo = window.localStorage.getItem('loginInfo');
//     const parsedUserInfo = JSON.parse(storedUserInfo);
//     setUserInfo(parsedUserInfo);
//   }, []);
//   return (
//     <UserInfoContext.Provider value={userInfo}>
//       {children}
//     </UserInfoContext.Provider>
//   );
// };
// export const useUserInfo = () => useContext(UserInfoContext);
// components/UserInfoContext.js


const UserInfoContext = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_1__.createContext)();
const UserInfoProvider = ({ children  })=>{
    const [userInfo, setUserInfo] = useState(null);
    useEffect(()=>{
        if (false) {}
    }, []);
    return /*#__PURE__*/ _jsx(UserInfoContext.Provider, {
        value: userInfo,
        children: children
    });
};
const useUserInfo = ()=>(0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(UserInfoContext);


/***/ })

};
;