"use strict";
exports.id = 931;
exports.ids = [931];
exports.modules = {

/***/ 1748:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1185);
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mongoose__WEBPACK_IMPORTED_MODULE_0__);

const BlogPostSchema = new (mongoose__WEBPACK_IMPORTED_MODULE_0___default().Schema)({
    userid: {
        type: String
    },
    blogtitle: {
        type: String,
        required: true
    },
    blogdescription: {
        type: String,
        required: true
    },
    blgIMG_64: {
        type: String,
        required: true
    },
    publishdate: {
        type: String,
        required: true
    }
}, {
    timestamps: true
});
const BlogPost = (mongoose__WEBPACK_IMPORTED_MODULE_0___default().models.BlogPost) || mongoose__WEBPACK_IMPORTED_MODULE_0___default().model("BlogPost", BlogPostSchema);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (BlogPost);


/***/ }),

/***/ 5966:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1185);
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mongoose__WEBPACK_IMPORTED_MODULE_0__);
// lib/db.js

const connectDB = async ()=>{
    if ((mongoose__WEBPACK_IMPORTED_MODULE_0___default().connections[0].readyState)) return;
    try {
        await mongoose__WEBPACK_IMPORTED_MODULE_0___default().connect("mongodb://localhost:27017/blogDB", {
            useNewUrlParser: true,
            useUnifiedTopology: true
        });
        console.log("Connected to MongoDB");
    } catch (error) {
        console.error("Error connecting to MongoDB", error);
        throw new Error("Error connecting to MongoDB");
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (connectDB);


/***/ })

};
;