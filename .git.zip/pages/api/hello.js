export default function handler(err,res){

    res.status(200).json({name:"adeel"})
}